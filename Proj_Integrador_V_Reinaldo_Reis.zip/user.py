## API Criada por Reinaldo Martins Reis RA 4201315 do Grupo Super Sam
## Criado uma as formas de leitura, gravação e alteração dos dados na base de dados
##
import csv
from typing import Counter

#Funçao para buscar senha no arquivo de senhas e validar se o username e senha etão nesse arquivo
def abre_arquivod(username,senha):
        arquivo_aberto = open('arquivo.txt', 'r')
        texto = csv.reader(arquivo_aberto,delimiter=',')
        for linha in texto:
               nomearq = (linha[0])
               senhaarq = (linha[1])  
               if (username == nomearq and senhaarq == senha):   
                   return ('OK')
        if (username != nomearq or senhaarq != senha):         
           return ('ERRO')

