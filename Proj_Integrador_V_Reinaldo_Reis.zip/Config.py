## API Criada por Reinaldo Martins Reis RA 4201315 do Grupo Super Sam
## Criado uma as formas de leitura, gravação e alteração dos dados na base de dados
##
import random
import string



str_aleatoria = string.ascii_letters + string.digits + string.ascii_uppercase
chave = ''.join(random.choice(str_aleatoria) for i in range(12))
debug = True

SECRET_KEY = chave


