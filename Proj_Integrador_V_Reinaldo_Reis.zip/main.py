## API Criada por Reinaldo Martins Reis RA 4201315 do Grupo Super Sam
## Criado uma as formas de leitura, gravação e alteração dos dados na base de dados
from flask import Flask, request,jsonify
from flask_restful import reqparse


def insertImigrante(nome, pais, Data_Nasc, sexo):
    # Insere dados do Imigrante na base de dados do nosso Sistema
     return {"nome": nome, "pais": pais, "Data_Nasc": Data_Nasc,"sexo": sexo}


def atualizaImigrante(Codigo):
    # Altera dados do Imigrante na base de dados
    status = "Alterado" #fazer select na base para retornar dados do imigrante
    return {"Id_Imigrante": Codigo,"status":status}
       

def SelectImigrante(Codigo):
    # Busca dados do Imigrante na base de dados
    nome = "imigrante X" #fazer select na base para retornar dados do imigrante
    status = "Ativo" #fazer select na base para retornar dados do imigrante
    return {"Id_Imigrante": Codigo,"nome": nome,"status":status}




